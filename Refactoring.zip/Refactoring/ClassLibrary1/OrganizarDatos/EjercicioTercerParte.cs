﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.OrganizarDatos
{
    public class EjercicioTercerParte
    {
        public int cantPatas;
        public string nombre;
        public double edad;
        public int perro;
        public int pato;
        public int tipo;
    }

    public class LibretaSalud
    {
        public EjercicioTercerParte mascota;
        public string NombreMascota() => mascota.nombre;
        public int CantidadPatasMascota() => mascota.cantPatas;
        public double EdadMascota() => mascota.edad;

    }







}
