﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.OrganizarDatos.Solucion
{

    //SOLUCION Usar tecnica de Reemplazar el código de tipo con subclases y Encapsular los campos

    public class Mascota
    {
        private int cantPatas;
        private string nombre;
        private double edad;

        public int CantPatas
        {
            get { return cantPatas; }
            set { cantPatas = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public double Edad
        {
            get { return edad; }
            set { edad = value; }
        }

    }

    public class Perro:Mascota
    {
        private int cantPatas = 4;
    }

    public class Pato : Mascota
    {
        private int cantPatas = 2;

    }

    public class LibretaSalud
    {
        private Mascota mascota;
        LibretaSalud(Mascota mascota)
        {
            this.mascota = mascota;
        }

        public string NombreMascota() => mascota.Nombre;
        public int CantidadPatasMascota() => mascota.CantPatas;
        public double EdadMascota() => mascota.Edad;

    }
}
