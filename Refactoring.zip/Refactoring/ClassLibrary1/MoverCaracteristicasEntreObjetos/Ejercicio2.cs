﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.MoverCaracteristicasEntreObjetos
{

    public class Carrera
    {
        Titulo titulo;
        Titulacion titulacion;
    }

    public class Titulacion
    {
        public string traerTitulacion()
        {
            return new Titulo().traerTitulacion();
        }
        //metodos propios de la Titulacion
    }

    public class Titulo
    {
        string titulo;
        public string traerTitulacion()
        {
            return titulo;
        }
    }
}

