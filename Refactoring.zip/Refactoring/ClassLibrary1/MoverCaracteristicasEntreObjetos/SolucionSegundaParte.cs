﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.MoverCaracteristicasEntreObjetos
{
    class SolucionSegundaParte
    {
        //SOLUCION1:USAR TECNICA EXTRAER CLASE

        public class Persona
        {
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public int Genero { get; set; }
            public int Dni { get; set; }
            public Ubicacion Ubicacion { get; set; }

            public int TraerCuil()
            {
                //Se calcula el cuil mediante el Dni y el Genero
                return 112223334;
            }

            public string NombreCompleto() => this.Nombre + " " + this.Apellido;      

        }

        public class Ubicacion
        {
            private string Direccion;
            private string geo;

            public string CalcularUbicacionGeografia(string pais, string provincia, string localidad)
            {
                //CALCULOS
                this.geo = pais + provincia + localidad;
                return this.geo;
            }

            public string TraerCoordenadas()
            {
                //CALCULOS
                return "-345242424, -342245646";
            }

            public void MostrarEnMapa()
            {
                // return MAPs(TraerCoordenadas());
            }

        }

//*************SOLUCION2 TECNICA OCULTAR DELEGADO  ***********   
     public class Carrera{
            Titulacion titulo;
            //metodos propios de la carrera
    }

    public class Titulacion
    {
        public string traerTitulo()
        {
            return new Titulo().traerTitulo();
        }
            //metodos propios de la Titulacion
    }
    public class Titulo
    {
        string titulo;
        public string traerTitulo()
        {
            return titulo;
        }
    }
}
    //Tambien se podria eliminar la clase Titulo y pasar su unico metodo a la clase Titulacion.
}
