﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.MoverCaracteristicasEntreObjetos
{
    public class Persona
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Genero { get; set; }
        public int Dni { get; set; }
        public string Direccion { get; set; }
        public string Barrio { get; set; }
        public string Localidad { get; set; }
        public string Provincia { get; set; }
        public string Pais { get; set; }

        public int TraerCuil()
        {
            //Calculo del cuil mediante el Dni y Genero
            return 112223334;
        }

        public string NombreCompleto()
        {
            return this.Nombre + " " + this.Apellido;
        }


        public string CalcularUbicacionGeografia()
        {
            //se realiza un caluculo utilizando los campos Pais, Provincia, localidad y barrio de persona 
            //solicitudes y envios  a la API Maps para obtener calculo
            string geo = this.Pais + this.Provincia + this.Barrio + this.Localidad;
            return geo;
        }

        public string TraerCoordenadas()
        {
            //Las coordenadas se obtienen calculando la ubicacion geografica y la direccion.
            //llamadas a la API Maps...
            string coordenadas = CalcularUbicacionGeografia() + this.Direccion;
            return "-345242424, -342245646";
        }

        public void MostrarEnMapa()
        {
            // return MAPs(TraerCoordenadas());
        }

    }
}


