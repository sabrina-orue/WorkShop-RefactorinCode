﻿using System;

namespace RefactoringCodeSolucion
{
    public class PrimerGrupoDeTecnicas
    {

        // SOLUCION1: Utilizar la tecnica EXTRAER METODO Y METODO EN LINEA
        public void RealizarCalculos(int radio)
        {
            CalcularArea(radio);
            CalcularDiametro(radio);
            CalcularPerimetro(radio);
        }

        public void CalcularArea(double radio) => Console.Write("El AREA del Circulo es: " + Math.PI * radio * radio);

        public void CalcularPerimetro(double radio) => Console.Write("El PERIMETRO del Circulo es: " + 2 * Math.PI * radio);

        public void CalcularDiametro(double radio) => Console.Write("El DIAMETRO del Circulo es: " + 2 * radio);



    }

    //SOLUCION2: Utilizar tecnica "Reemplazar método con objeto de método", "Reemplazar la variable temporal con la consulta" y "variable temporal en linea"

    public class Orden
    {
        public string producto { get; set; }
        public int cantidad { get; set; }
        public double descuento { get; set; }
        public double total { get; set; }    
    }

    public class CalcularPrecio
    {
        public double PrecioTotal(Orden orden)
        {
            var precio = PrecioPorCantidad(orden.cantidad, PrecioDeProducto(orden.producto));
            return AplicarDescuento(orden.descuento, precio);
        }

        public double PrecioDeProducto(string producto) => 165.50;
        public double PrecioPorCantidad(int cantidad, double precioUnidad) => cantidad * precioUnidad;
        public double AplicarDescuento(double descuento, double precio) => precio - descuento * precio;
    }
}
