﻿using System;

namespace RefactoringCodeEjercicio
{
    public class PrimerGrupoDeTecnicas
    {

        public void RealizarCalculos(int r)
        {
            double a = Math.PI * r * r;
            double per = 2 * Math.PI * r;
            double diam = 2 * r;

            Console.Write("El AREA del Circulo es: " + a);
            Console.Write("El PERIMETRO del Circulo es: " + per);
            Console.Write("El DIAMETRO del Circulo es: " + diam);

        }
    }

    public class Orden
    {
        string producto;
        int cantidad;
        readonly double descuento;
        double total;
        bool tieneDescuento;

        public Orden(int cantidad, double descuento, string producto)
        {

            this.cantidad = cantidad;
            this.descuento = descuento;
            this.producto = producto;

        }

        public double CalcularPrecioPorCantidad(int cantidad, double precioUnidad)
        {
            var precio = cantidad * precioUnidad;
            return precio;

        }
        public double AplicarDescuento(int descuento, double precio)
        {
            precio -= (descuento * precio);
            return precio;
        }

        public double TraerPrecioDeProducto(string producto)
        {

            var precio = 165.50;
            return precio;
        }

    }

}
