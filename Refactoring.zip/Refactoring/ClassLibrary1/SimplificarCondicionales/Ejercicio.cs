﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.SimplificarCondicionales
{
    public class Nested
    {
        private string client;
        private string country;
        private string location;
        private string ListMatchingTheCriteria;
        private string ListMatchingTheCriteria2;


        public string CheckMethod()
        {

            if (client == "Client1")
            {
                if (location == "Location1" && country == "Country1")
                {
                    return ListMatchingTheCriteria;
                }
                else
                {
                    return String.Empty;
                }
            }
            else if (client == "Client2")
            {
                if (location == "Location2" && country == "Country2")
                {
                    return ListMatchingTheCriteria;
                }
                else
                {
                    return String.Empty;
                }
            }
            else
            {
                return ListMatchingTheCriteria2;
            }
        }

    }
}
