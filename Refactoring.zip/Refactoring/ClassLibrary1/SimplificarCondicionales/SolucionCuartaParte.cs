﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefactoringCode.SimplificarCondicionales.Solucion
{

    // SOLUCION: Consolidar la expresión condicional, 
    //          Consolidar duplicados fragmentos condicionales
    //          Reemplazar condicional anidado con cláusulas




    public class Nested
    {
        private string client;
        private string country;
        private string location;
        private string ListMatchingTheCriteria;
        private string ListMatchingTheCriteria2;

        private bool IsClient1_2 => (client == "Client1" || client == "Client2");
        private bool IsLocationCountry_1 => (location == "Location1" && country == "Country1");
        private bool IsLocationCountry_2 => (location == "Location2" && country == "Country2");


        public string CheckMethod()
        {
            if (IsClient1_2)
            {
                if (IsLocationCountry_1 || IsLocationCountry_2)
                {
                    return ListMatchingTheCriteria;
                }
            }
            else
            {
                return ListMatchingTheCriteria2;
            };
            return String.Empty;
        }

    }
}
